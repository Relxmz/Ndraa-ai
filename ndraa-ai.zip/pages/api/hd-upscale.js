import { IncomingForm } from "formidable";
import { readFile } from "node:fs/promises";
import { extname } from "node:path";

export const config = {
  api: {
    bodyParser: false,
  },
};

const API = "https://sparkpix.ai/api/free-hd-upscale";
const REFERER = "https://sparkpix.ai/aitools/free-hd-upscaler";
const UA =
  "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36";

function mimeFromPath(filePath = "") {
  const ext = extname(filePath).toLowerCase();
  if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
  if (ext === ".png") return "image/png";
  if (ext === ".webp") return "image/webp";
  return "image/jpeg";
}

function parseQuality(input = "4k") {
  const raw = String(input).toLowerCase().replace(/\s+/g, "");
  if (["8k", "4", "4x"].includes(raw)) return { quality: "8K", scale: "4" };
  if (["6k", "3", "3x"].includes(raw)) return { quality: "6K", scale: "3" };
  return { quality: "4K", scale: "2" };
}

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const form = new IncomingForm({ maxFileSize: 20 * 1024 * 1024 });

  form.parse(req, async (err, fields, files) => {
    if (err) {
      return res.status(400).json({ error: "Gagal memproses file: " + err.message });
    }

    try {
      const file = files.file?.[0] || files.file;
      const qualityInput = fields.quality?.[0] || fields.quality || "4k";
      const faceEnhance = (fields.faceEnhance?.[0] || fields.faceEnhance || "false") === "true";

      if (!file) {
        return res.status(400).json({ error: "File diperlukan" });
      }

      const { quality, scale } = parseQuality(qualityInput);
      const buffer = await readFile(file.filepath);
      const mime = file.mimetype || mimeFromPath(file.originalFilename || "");
      const filename = file.originalFilename || "image.jpg";

      const formData = new FormData();
      const blob = new Blob([buffer], { type: mime });
      formData.append("file", blob, filename);
      formData.append("scale", scale);
      formData.append("face_enhance", String(faceEnhance));

      const sparkRes = await fetch(API, {
        method: "POST",
        headers: {
          accept: "*/*",
          origin: "https://sparkpix.ai",
          referer: REFERER,
          "user-agent": UA,
        },
        body: formData,
      });

      const text = await sparkRes.text();
      let json;
      try {
        json = JSON.parse(text);
      } catch {
        json = null;
      }

      if (!sparkRes.ok || !json?.success || !json?.resultUrl) {
        return res.status(500).json({
          error: "Gagal memproses gambar",
          detail: json || text.slice(0, 200),
        });
      }

      const downloadUrl = `https://sparkpix.ai/api/download-image?url=${encodeURIComponent(json.resultUrl)}`;

      return res.status(200).json({
        success: true,
        resultUrl: json.resultUrl,
        downloadUrl,
        quality,
        scale,
        processingTime: json.processingTime,
      });
    } catch (error) {
      console.error("HD Upscale error:", error);
      return res.status(500).json({
        error: "Terjadi kesalahan saat memproses",
        detail: error.message,
      });
    }
  });
}
