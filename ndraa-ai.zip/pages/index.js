import { useState, useRef, useEffect, useCallback } from "react";
import Head from "next/head";

export default function Home() {
  const [showWelcome, setShowWelcome] = useState(true);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [thinkingText, setThinkingText] = useState("");
  const [showHDModal, setShowHDModal] = useState(false);
  const [hdFile, setHdFile] = useState(null);
  const [hdQuality, setHdQuality] = useState("4k");
  const [hdFace, setHdFace] = useState(false);
  const [hdLoading, setHdLoading] = useState(false);
  const [hdResult, setHdResult] = useState(null);
  const [hdError, setHdError] = useState("");
  const [hdPreview, setHdPreview] = useState(null);
  const chatEndRef = useRef(null);
  const inputRef = useRef(null);
  const hdFileRef = useRef(null);

  const thinkingPhrases = [
    "Sedang berpikir...",
    "Menganalisis pertanyaan Anda...",
    "Mencari jawaban terbaik...",
    "Memproses informasi...",
    "Sedang mencari...",
    "Menyusun respons...",
  ];

  useEffect(() => {
    let i = 0;
    if (isThinking) {
      const interval = setInterval(() => {
        i = (i + 1) % thinkingPhrases.length;
        setThinkingText(thinkingPhrases[i]);
      }, 1200);
      setThinkingText(thinkingPhrases[0]);
      return () => clearInterval(interval);
    }
  }, [isThinking]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isThinking]);

  const handleStart = () => {
    setShowWelcome(false);
    setTimeout(() => inputRef.current?.focus(), 300);
  };

  const buildHistory = () => {
    const hist = [];
    for (let i = 0; i < messages.length - 1; i += 2) {
      if (messages[i] && messages[i + 1]) {
        hist.push({ user: messages[i].content, assistant: messages[i + 1].content });
      }
    }
    return hist;
  };

  const sendMessage = useCallback(async () => {
    const text = input.trim();
    if (!text || isLoading) return;

    const userMsg = { role: "user", content: text };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsLoading(true);
    setIsThinking(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: text, history: buildHistory() }),
      });

      const data = await response.json();
      setIsThinking(false);

      if (data.error) {
        setMessages((prev) => [
          ...prev,
          { role: "assistant", content: "❌ " + (data.error || "Terjadi kesalahan, coba lagi."), isError: true },
        ]);
      } else {
        const aiReply = data.answer || data.reasoning || "Maaf, saya tidak bisa memberikan respons saat ini.";
        setMessages((prev) => [
          ...prev,
          { role: "assistant", content: aiReply, reasoning: data.reasoning && data.answer ? data.reasoning : null },
        ]);
      }
    } catch (err) {
      setIsThinking(false);
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: "❌ Koneksi gagal, silakan coba lagi.", isError: true },
      ]);
    } finally {
      setIsLoading(false);
    }
  }, [input, isLoading, messages]);

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleReset = () => {
    setMessages([]);
    setInput("");
    setShowWelcome(false);
    setTimeout(() => inputRef.current?.focus(), 100);
  };

  const handleHDFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setHdFile(file);
    setHdResult(null);
    setHdError("");
    const reader = new FileReader();
    reader.onload = (ev) => setHdPreview(ev.target.result);
    reader.readAsDataURL(file);
  };

  const handleHDUpscale = async () => {
    if (!hdFile) return;
    setHdLoading(true);
    setHdResult(null);
    setHdError("");

    try {
      const formData = new FormData();
      formData.append("file", hdFile);
      formData.append("quality", hdQuality);
      formData.append("faceEnhance", String(hdFace));

      const res = await fetch("/api/hd-upscale", {
        method: "POST",
        body: formData,
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        setHdError(data.error || "Gagal memproses gambar");
      } else {
        setHdResult(data);
      }
    } catch (err) {
      setHdError("Koneksi gagal: " + err.message);
    } finally {
      setHdLoading(false);
    }
  };

  const formatMessage = (content) => {
    if (!content) return "";
    return content
      .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
      .replace(/\*(.*?)\*/g, "<em>$1</em>")
      .replace(/`(.*?)`/g, "<code>$1</code>")
      .replace(/\n/g, "<br/>");
  };

  return (
    <>
      <Head>
        <title>NDRAA AI - AI Cerdas oleh Rendra A.F</title>
        <meta name="description" content="NDRAA AI - AI cerdas yang dikembangkan oleh Ndra, dirancang untuk membantu berbagai kebutuhan Anda." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet" />
      </Head>

      <div className="root">
        {/* WELCOME SCREEN */}
        {showWelcome && (
          <div className="welcome-overlay">
            <div className="welcome-bg-anim" />
            <div className="welcome-card">
              <div className="welcome-logo-ring">
                <div className="welcome-logo-inner">
                  <span className="welcome-logo-text">N</span>
                </div>
              </div>
              <h1 className="welcome-title">
                Selamat Datang di<br />
                <span className="welcome-brand">NDRAA AI</span>
              </h1>
              <p className="welcome-desc">
                AI cerdas yang dikembangkan oleh <strong>Ndra</strong>, dirancang untuk membantu Anda dalam berbagai hal — dari menjawab pertanyaan, berpikir mendalam, hingga meningkatkan kualitas gambar menjadi HD.
              </p>
              <div className="welcome-features">
                <div className="welcome-feat">
                  <span className="feat-icon">🧠</span>
                  <span>Berpikir Mendalam</span>
                </div>
                <div className="welcome-feat">
                  <span className="feat-icon">🔍</span>
                  <span>Cari & Analisis</span>
                </div>
                <div className="welcome-feat">
                  <span className="feat-icon">✨</span>
                  <span>HD Upscale</span>
                </div>
              </div>
              <button className="welcome-btn" onClick={handleStart}>
                Mulai Sekarang
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <path d="M5 12h14M12 5l7 7-7 7" />
                </svg>
              </button>
              <p className="welcome-credit">NDRAA AI — oleh Rendra A.F</p>
            </div>
          </div>
        )}

        {/* MAIN APP */}
        <div className={`app-shell ${showWelcome ? "hidden" : "visible"}`}>
          {/* HEADER */}
          <header className="header">
            <div className="header-left">
              <div className="header-logo">
                <div className="logo-orb" />
                <span className="header-brand">NDRAA AI</span>
              </div>
              <span className="header-tagline">by Rendra A.F</span>
            </div>
            <div className="header-right">
              <button className="hd-btn" onClick={() => { setShowHDModal(true); setHdResult(null); setHdError(""); setHdPreview(null); setHdFile(null); }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="2" y="3" width="20" height="14" rx="2" />
                  <path d="M8 21h8M12 17v4" />
                  <path d="M7 10h2v-3h2v3h2V7h-6v3zM14 7v6h2V7h-2z" fill="currentColor" stroke="none"/>
                </svg>
                HD
              </button>
              <button className="reset-btn" onClick={handleReset} title="Mulai Ulang">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
                  <path d="M3 3v5h5" />
                </svg>
                Mulai Ulang
              </button>
            </div>
          </header>

          {/* CHAT AREA */}
          <main className="chat-area">
            {messages.length === 0 && (
              <div className="empty-state">
                <div className="empty-orb-container">
                  <div className="empty-orb" />
                  <div className="empty-orb-ring" />
                </div>
                <h2 className="empty-title">Halo! Saya NDRAA AI</h2>
                <p className="empty-sub">Tanyakan apa saja kepada saya. Saya siap membantu Anda berpikir, mencari, dan menganalisis.</p>
                <div className="suggestion-chips">
                  {["Apa itu kecerdasan buatan?", "Siapa yang membuat kamu?", "Bantu saya membuat esai", "Jelaskan fotosintesis"].map((s) => (
                    <button key={s} className="chip" onClick={() => { setInput(s); inputRef.current?.focus(); }}>
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="messages-list">
              {messages.map((msg, i) => (
                <div key={i} className={`message-row ${msg.role}`}>
                  {msg.role === "assistant" && (
                    <div className="avatar-ai">
                      <span>N</span>
                    </div>
                  )}
                  <div className={`bubble ${msg.role} ${msg.isError ? "error" : ""}`}>
                    {msg.reasoning && (
                      <details className="reasoning-block">
                        <summary>🧠 Proses Berpikir</summary>
                        <div className="reasoning-content" dangerouslySetInnerHTML={{ __html: formatMessage(msg.reasoning) }} />
                      </details>
                    )}
                    <div dangerouslySetInnerHTML={{ __html: formatMessage(msg.content) }} />
                  </div>
                  {msg.role === "user" && (
                    <div className="avatar-user">
                      <span>U</span>
                    </div>
                  )}
                </div>
              ))}

              {isThinking && (
                <div className="message-row assistant">
                  <div className="avatar-ai thinking-avatar">
                    <span>N</span>
                  </div>
                  <div className="bubble assistant thinking-bubble">
                    <div className="thinking-indicator">
                      <div className="thinking-dots">
                        <span /><span /><span />
                      </div>
                      <span className="thinking-label">{thinkingText}</span>
                    </div>
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>
          </main>

          {/* INPUT BAR */}
          <div className="input-section">
            <div className="input-wrapper">
              <textarea
                ref={inputRef}
                className="chat-input"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Tulis perintah atau pertanyaan Anda..."
                rows={1}
                disabled={isLoading}
              />
              <div className="input-actions">
                <button
                  className="hd-inline-btn"
                  onClick={() => { setShowHDModal(true); setHdResult(null); setHdError(""); setHdPreview(null); setHdFile(null); }}
                  title="HD Upscale Foto"
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="2" y="3" width="20" height="14" rx="2"/>
                    <path d="M8 21h8M12 17v4"/>
                  </svg>
                  HD
                </button>
                <button
                  className={`send-btn ${isLoading ? "loading" : ""}`}
                  onClick={sendMessage}
                  disabled={isLoading || !input.trim()}
                >
                  {isLoading ? (
                    <div className="send-spinner" />
                  ) : (
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" />
                    </svg>
                  )}
                </button>
              </div>
            </div>
            <p className="input-hint">Tekan Enter untuk kirim • Shift+Enter untuk baris baru</p>
          </div>
        </div>

        {/* HD MODAL */}
        {showHDModal && (
          <div className="modal-overlay" onClick={(e) => { if (e.target === e.currentTarget) setShowHDModal(false); }}>
            <div className="hd-modal">
              <div className="modal-header">
                <h2 className="modal-title">
                  <span className="hd-badge">HD</span>
                  Tingkatkan Kualitas Foto
                </h2>
                <button className="modal-close" onClick={() => setShowHDModal(false)}>
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M18 6L6 18M6 6l12 12" />
                  </svg>
                </button>
              </div>

              <div className="modal-body">
                {/* Upload Area */}
                <div className="upload-zone" onClick={() => hdFileRef.current?.click()}>
                  {hdPreview ? (
                    <img src={hdPreview} alt="Preview" className="upload-preview" />
                  ) : (
                    <div className="upload-placeholder">
                      <div className="upload-icon-wrap">
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                          <polyline points="17 8 12 3 7 8"/>
                          <line x1="12" y1="3" x2="12" y2="15"/>
                        </svg>
                      </div>
                      <p className="upload-text">Klik untuk upload foto</p>
                      <p className="upload-hint-text">JPG, PNG, WEBP — Maks 20MB</p>
                    </div>
                  )}
                  <input
                    ref={hdFileRef}
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    style={{ display: "none" }}
                    onChange={handleHDFileChange}
                  />
                </div>

                {/* Options */}
                <div className="hd-options">
                  <div className="hd-option-group">
                    <label className="option-label">Kualitas Output</label>
                    <div className="quality-btns">
                      {["4k", "6k", "8k"].map((q) => (
                        <button
                          key={q}
                          className={`quality-btn ${hdQuality === q ? "active" : ""}`}
                          onClick={() => setHdQuality(q)}
                        >
                          {q.toUpperCase()}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="hd-option-group">
                    <label className="option-label option-toggle">
                      <span>Perbaiki Wajah</span>
                      <div className={`toggle ${hdFace ? "on" : ""}`} onClick={() => setHdFace(!hdFace)}>
                        <div className="toggle-thumb" />
                      </div>
                    </label>
                  </div>
                </div>

                {/* Process Button */}
                <button
                  className={`process-btn ${hdLoading ? "loading" : ""}`}
                  onClick={handleHDUpscale}
                  disabled={!hdFile || hdLoading}
                >
                  {hdLoading ? (
                    <><div className="btn-spinner" /> Memproses...</>
                  ) : (
                    <><span>✨</span> Tingkatkan ke {hdQuality.toUpperCase()}</>
                  )}
                </button>

                {/* Error */}
                {hdError && (
                  <div className="hd-error">❌ {hdError}</div>
                )}

                {/* Result */}
                {hdResult && (
                  <div className="hd-result">
                    <div className="result-badge">✅ Berhasil diproses — {hdResult.quality}</div>
                    <img src={hdResult.resultUrl} alt="HD Result" className="result-img" />
                    <div className="result-actions">
                      <a
                        href={hdResult.downloadUrl}
                        download="ndraa-hd-result.png"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="download-btn"
                      >
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                          <polyline points="17 8 12 3 7 8"/>
                          <line x1="12" y1="3" x2="12" y2="15"/>
                        </svg>
                        Download Hasil HD
                      </a>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      <style jsx global>{`
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
          --purple-deep: #0d0010;
          --purple-dark: #130020;
          --purple-mid: #6b21a8;
          --purple-bright: #a855f7;
          --purple-light: #d8b4fe;
          --purple-glow: #c084fc;
          --purple-faint: rgba(168,85,247,0.08);
          --purple-border: rgba(168,85,247,0.2);
          --text-primary: #f5f0ff;
          --text-secondary: rgba(245,240,255,0.6);
          --text-dim: rgba(245,240,255,0.35);
          --surface: rgba(30,0,50,0.6);
          --surface-raised: rgba(50,0,80,0.5);
          --radius: 16px;
          --radius-sm: 10px;
          --shadow-glow: 0 0 40px rgba(168,85,247,0.15);
        }

        html, body {
          height: 100%;
          font-family: 'DM Sans', sans-serif;
          background: var(--purple-deep);
          color: var(--text-primary);
          overflow: hidden;
        }

        .root {
          height: 100vh;
          width: 100vw;
          position: relative;
          overflow: hidden;
          background: radial-gradient(ellipse 80% 60% at 50% -10%, rgba(139,0,255,0.25) 0%, transparent 70%),
                      radial-gradient(ellipse 60% 40% at 100% 100%, rgba(100,0,200,0.15) 0%, transparent 60%),
                      var(--purple-deep);
        }

        /* ==================== WELCOME ==================== */
        .welcome-overlay {
          position: fixed; inset: 0; z-index: 100;
          display: flex; align-items: center; justify-content: center;
          background: radial-gradient(ellipse 100% 80% at 50% 0%, rgba(120,0,255,0.3) 0%, transparent 70%), var(--purple-deep);
          animation: fadeIn 0.5s ease;
        }

        .welcome-bg-anim {
          position: absolute; inset: 0; z-index: 0;
          background: 
            radial-gradient(circle at 20% 50%, rgba(168,85,247,0.1) 0%, transparent 40%),
            radial-gradient(circle at 80% 50%, rgba(139,92,246,0.08) 0%, transparent 40%);
          animation: bgPulse 4s ease-in-out infinite alternate;
        }

        @keyframes bgPulse {
          from { opacity: 0.5; }
          to { opacity: 1; }
        }

        .welcome-card {
          position: relative; z-index: 1;
          display: flex; flex-direction: column; align-items: center;
          max-width: 560px; width: 90%;
          padding: 52px 48px;
          background: rgba(20,0,35,0.85);
          border: 1px solid var(--purple-border);
          border-radius: 28px;
          backdrop-filter: blur(24px);
          box-shadow: 0 0 80px rgba(168,85,247,0.15), inset 0 1px 0 rgba(255,255,255,0.05);
          animation: slideUp 0.6s cubic-bezier(0.16,1,0.3,1);
          text-align: center;
        }

        @keyframes slideUp {
          from { opacity: 0; transform: translateY(30px) scale(0.97); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }

        .welcome-logo-ring {
          width: 96px; height: 96px;
          border-radius: 50%;
          border: 2px solid var(--purple-bright);
          display: flex; align-items: center; justify-content: center;
          margin-bottom: 28px;
          position: relative;
          animation: rotateSlow 8s linear infinite;
          box-shadow: 0 0 30px rgba(168,85,247,0.4), inset 0 0 20px rgba(168,85,247,0.1);
        }

        @keyframes rotateSlow {
          from { box-shadow: 0 0 30px rgba(168,85,247,0.4), inset 0 0 20px rgba(168,85,247,0.1); }
          50% { box-shadow: 0 0 50px rgba(168,85,247,0.6), inset 0 0 30px rgba(168,85,247,0.2); }
          to { box-shadow: 0 0 30px rgba(168,85,247,0.4), inset 0 0 20px rgba(168,85,247,0.1); }
        }

        .welcome-logo-inner {
          width: 70px; height: 70px; border-radius: 50%;
          background: linear-gradient(135deg, #7c3aed, #a855f7);
          display: flex; align-items: center; justify-content: center;
        }

        .welcome-logo-text {
          font-family: 'Syne', sans-serif;
          font-size: 32px; font-weight: 800;
          color: white;
        }

        .welcome-title {
          font-family: 'Syne', sans-serif;
          font-size: 28px; font-weight: 700;
          line-height: 1.25;
          margin-bottom: 16px;
          color: var(--text-primary);
        }

        .welcome-brand {
          background: linear-gradient(135deg, #c084fc, #a855f7, #7c3aed);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          font-size: 36px;
        }

        .welcome-desc {
          color: var(--text-secondary);
          font-size: 15px; line-height: 1.7;
          margin-bottom: 28px;
          max-width: 420px;
        }

        .welcome-features {
          display: flex; gap: 12px;
          margin-bottom: 36px;
          flex-wrap: wrap; justify-content: center;
        }

        .welcome-feat {
          display: flex; align-items: center; gap: 8px;
          padding: 8px 16px;
          background: var(--purple-faint);
          border: 1px solid var(--purple-border);
          border-radius: 100px;
          font-size: 13px; font-weight: 500;
          color: var(--purple-light);
        }

        .feat-icon { font-size: 16px; }

        .welcome-btn {
          display: flex; align-items: center; gap: 10px;
          padding: 16px 36px;
          background: linear-gradient(135deg, #7c3aed, #a855f7);
          border: none; border-radius: 100px;
          color: white; font-size: 16px; font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
          box-shadow: 0 8px 30px rgba(168,85,247,0.35);
          font-family: 'DM Sans', sans-serif;
        }

        .welcome-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 12px 40px rgba(168,85,247,0.5);
        }

        .welcome-credit {
          margin-top: 24px;
          font-size: 12px; color: var(--text-dim);
        }

        /* ==================== APP SHELL ==================== */
        .app-shell {
          display: flex; flex-direction: column;
          height: 100vh; width: 100%;
          transition: opacity 0.4s ease;
        }

        .hidden { opacity: 0; pointer-events: none; }
        .visible { opacity: 1; }

        /* HEADER */
        .header {
          display: flex; align-items: center; justify-content: space-between;
          padding: 0 28px;
          height: 64px;
          background: rgba(13,0,20,0.8);
          border-bottom: 1px solid var(--purple-border);
          backdrop-filter: blur(20px);
          flex-shrink: 0;
          z-index: 10;
        }

        .header-left { display: flex; align-items: center; gap: 12px; }

        .header-logo {
          display: flex; align-items: center; gap: 10px;
        }

        .logo-orb {
          width: 32px; height: 32px; border-radius: 50%;
          background: linear-gradient(135deg, #7c3aed, #a855f7);
          box-shadow: 0 0 16px rgba(168,85,247,0.5);
          animation: orbPulse 3s ease-in-out infinite;
        }

        @keyframes orbPulse {
          0%, 100% { box-shadow: 0 0 16px rgba(168,85,247,0.5); }
          50% { box-shadow: 0 0 28px rgba(168,85,247,0.8); }
        }

        .header-brand {
          font-family: 'Syne', sans-serif;
          font-size: 20px; font-weight: 800;
          background: linear-gradient(135deg, #c084fc, #a855f7);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .header-tagline {
          font-size: 12px;
          color: var(--text-dim);
          padding: 3px 8px;
          background: var(--purple-faint);
          border: 1px solid var(--purple-border);
          border-radius: 100px;
        }

        .header-right { display: flex; align-items: center; gap: 10px; }

        .hd-btn {
          display: flex; align-items: center; gap: 6px;
          padding: 8px 16px;
          background: linear-gradient(135deg, rgba(109,40,217,0.3), rgba(168,85,247,0.2));
          border: 1px solid rgba(168,85,247,0.4);
          border-radius: 10px;
          color: var(--purple-light);
          font-size: 13px; font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          font-family: 'DM Sans', sans-serif;
        }

        .hd-btn:hover {
          background: linear-gradient(135deg, rgba(109,40,217,0.5), rgba(168,85,247,0.35));
          border-color: var(--purple-bright);
          color: white;
        }

        .reset-btn {
          display: flex; align-items: center; gap: 6px;
          padding: 8px 16px;
          background: transparent;
          border: 1px solid var(--purple-border);
          border-radius: 10px;
          color: var(--text-secondary);
          font-size: 13px;
          cursor: pointer;
          transition: all 0.2s;
          font-family: 'DM Sans', sans-serif;
        }

        .reset-btn:hover {
          border-color: var(--purple-bright);
          color: var(--purple-light);
          background: var(--purple-faint);
        }

        /* CHAT AREA */
        .chat-area {
          flex: 1; overflow-y: auto;
          padding: 32px 0;
          scroll-behavior: smooth;
        }

        .chat-area::-webkit-scrollbar { width: 4px; }
        .chat-area::-webkit-scrollbar-track { background: transparent; }
        .chat-area::-webkit-scrollbar-thumb { background: var(--purple-border); border-radius: 2px; }

        /* EMPTY STATE */
        .empty-state {
          display: flex; flex-direction: column; align-items: center;
          justify-content: center;
          padding: 60px 24px;
          text-align: center;
          animation: fadeIn 0.6s ease;
        }

        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(16px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .empty-orb-container {
          position: relative;
          width: 120px; height: 120px;
          margin-bottom: 32px;
        }

        .empty-orb {
          position: absolute; inset: 20px;
          border-radius: 50%;
          background: linear-gradient(135deg, #7c3aed, #a855f7);
          box-shadow: 0 0 40px rgba(168,85,247,0.5);
          animation: orbPulse 3s ease-in-out infinite;
        }

        .empty-orb-ring {
          position: absolute; inset: 0;
          border-radius: 50%;
          border: 1px solid rgba(168,85,247,0.3);
          animation: ringExpand 3s ease-in-out infinite;
        }

        @keyframes ringExpand {
          0%, 100% { transform: scale(1); opacity: 0.5; }
          50% { transform: scale(1.15); opacity: 0; }
        }

        .empty-title {
          font-family: 'Syne', sans-serif;
          font-size: 26px; font-weight: 700;
          margin-bottom: 12px;
          background: linear-gradient(135deg, #f5f0ff, #c084fc);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .empty-sub {
          color: var(--text-secondary);
          font-size: 15px; line-height: 1.6;
          max-width: 480px; margin-bottom: 32px;
        }

        .suggestion-chips {
          display: flex; flex-wrap: wrap; gap: 10px;
          justify-content: center;
        }

        .chip {
          padding: 10px 18px;
          background: var(--purple-faint);
          border: 1px solid var(--purple-border);
          border-radius: 100px;
          color: var(--purple-light);
          font-size: 13px; font-weight: 500;
          cursor: pointer;
          transition: all 0.2s;
          font-family: 'DM Sans', sans-serif;
        }

        .chip:hover {
          background: rgba(168,85,247,0.15);
          border-color: var(--purple-bright);
          color: white; transform: translateY(-1px);
        }

        /* MESSAGES */
        .messages-list {
          max-width: 860px; margin: 0 auto;
          padding: 0 24px;
          display: flex; flex-direction: column; gap: 20px;
        }

        .message-row {
          display: flex; align-items: flex-start; gap: 14px;
          animation: msgSlide 0.3s ease;
        }

        @keyframes msgSlide {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .message-row.user { flex-direction: row-reverse; }

        .avatar-ai, .avatar-user {
          width: 38px; height: 38px; border-radius: 50%;
          display: flex; align-items: center; justify-content: center;
          font-family: 'Syne', sans-serif;
          font-size: 16px; font-weight: 700;
          flex-shrink: 0;
        }

        .avatar-ai {
          background: linear-gradient(135deg, #7c3aed, #a855f7);
          box-shadow: 0 0 16px rgba(168,85,247,0.4);
          color: white;
        }

        .avatar-user {
          background: rgba(255,255,255,0.08);
          border: 1px solid rgba(255,255,255,0.15);
          color: var(--text-secondary);
        }

        .thinking-avatar {
          animation: avatarGlow 1.5s ease-in-out infinite;
        }

        @keyframes avatarGlow {
          0%, 100% { box-shadow: 0 0 16px rgba(168,85,247,0.4); }
          50% { box-shadow: 0 0 30px rgba(168,85,247,0.8); }
        }

        .bubble {
          max-width: 70%; padding: 16px 20px;
          border-radius: 18px;
          font-size: 15px; line-height: 1.7;
          word-break: break-word;
        }

        .bubble.assistant {
          background: rgba(30,0,50,0.7);
          border: 1px solid var(--purple-border);
          color: var(--text-primary);
          border-radius: 4px 18px 18px 18px;
          backdrop-filter: blur(12px);
        }

        .bubble.user {
          background: linear-gradient(135deg, rgba(109,40,217,0.5), rgba(168,85,247,0.3));
          border: 1px solid rgba(168,85,247,0.3);
          color: var(--text-primary);
          border-radius: 18px 4px 18px 18px;
        }

        .bubble.error {
          background: rgba(255,50,50,0.1);
          border-color: rgba(255,50,50,0.3);
          color: #fca5a5;
        }

        .bubble code {
          background: rgba(168,85,247,0.15);
          border: 1px solid var(--purple-border);
          border-radius: 4px;
          padding: 1px 6px;
          font-size: 13px;
          font-family: monospace;
          color: var(--purple-light);
        }

        .reasoning-block {
          margin-bottom: 12px;
          border: 1px solid var(--purple-border);
          border-radius: 10px;
          overflow: hidden;
        }

        .reasoning-block summary {
          padding: 8px 12px;
          background: var(--purple-faint);
          cursor: pointer;
          font-size: 13px;
          color: var(--purple-light);
          font-weight: 500;
          user-select: none;
        }

        .reasoning-content {
          padding: 12px;
          font-size: 13px; color: var(--text-secondary);
          line-height: 1.6;
        }

        /* THINKING */
        .thinking-bubble {
          display: flex; align-items: center; gap: 12px;
        }

        .thinking-indicator {
          display: flex; align-items: center; gap: 12px;
        }

        .thinking-dots {
          display: flex; gap: 5px;
        }

        .thinking-dots span {
          width: 7px; height: 7px;
          border-radius: 50%;
          background: var(--purple-bright);
          animation: dotBounce 1.2s ease-in-out infinite;
        }

        .thinking-dots span:nth-child(2) { animation-delay: 0.2s; }
        .thinking-dots span:nth-child(3) { animation-delay: 0.4s; }

        @keyframes dotBounce {
          0%, 80%, 100% { transform: scale(0.7); opacity: 0.5; }
          40% { transform: scale(1.1); opacity: 1; }
        }

        .thinking-label {
          font-size: 14px; color: var(--purple-light);
          font-style: italic;
          animation: labelFade 1.2s ease-in-out infinite alternate;
        }

        @keyframes labelFade {
          from { opacity: 0.6; }
          to { opacity: 1; }
        }

        /* INPUT SECTION */
        .input-section {
          padding: 16px 24px 20px;
          background: rgba(13,0,20,0.8);
          border-top: 1px solid var(--purple-border);
          backdrop-filter: blur(20px);
          flex-shrink: 0;
        }

        .input-wrapper {
          max-width: 860px; margin: 0 auto;
          display: flex; align-items: flex-end; gap: 10px;
          background: rgba(30,0,50,0.7);
          border: 1px solid var(--purple-border);
          border-radius: 18px;
          padding: 12px 12px 12px 20px;
          transition: border-color 0.2s, box-shadow 0.2s;
          backdrop-filter: blur(12px);
        }

        .input-wrapper:focus-within {
          border-color: var(--purple-bright);
          box-shadow: 0 0 0 3px rgba(168,85,247,0.12);
        }

        .chat-input {
          flex: 1;
          background: transparent;
          border: none; outline: none;
          color: var(--text-primary);
          font-family: 'DM Sans', sans-serif;
          font-size: 15px; line-height: 1.6;
          resize: none;
          max-height: 180px;
          scrollbar-width: none;
        }

        .chat-input::placeholder { color: var(--text-dim); }
        .chat-input:disabled { opacity: 0.6; }

        .input-actions {
          display: flex; align-items: center; gap: 8px;
          flex-shrink: 0;
        }

        .hd-inline-btn {
          display: flex; align-items: center; gap: 5px;
          padding: 8px 12px;
          background: rgba(109,40,217,0.2);
          border: 1px solid rgba(168,85,247,0.3);
          border-radius: 12px;
          color: var(--purple-light);
          font-size: 12px; font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          font-family: 'DM Sans', sans-serif;
          white-space: nowrap;
        }

        .hd-inline-btn:hover {
          background: rgba(109,40,217,0.4);
          border-color: var(--purple-bright);
          color: white;
        }

        .send-btn {
          width: 44px; height: 44px;
          border-radius: 13px;
          background: linear-gradient(135deg, #7c3aed, #a855f7);
          border: none;
          display: flex; align-items: center; justify-content: center;
          cursor: pointer;
          transition: all 0.2s;
          flex-shrink: 0;
          box-shadow: 0 4px 16px rgba(168,85,247,0.35);
        }

        .send-btn:hover:not(:disabled) {
          transform: scale(1.05);
          box-shadow: 0 6px 22px rgba(168,85,247,0.5);
        }

        .send-btn:disabled { opacity: 0.5; cursor: not-allowed; transform: none; }

        .send-btn svg { color: white; }

        .send-spinner {
          width: 18px; height: 18px;
          border: 2px solid rgba(255,255,255,0.3);
          border-top-color: white;
          border-radius: 50%;
          animation: spin 0.7s linear infinite;
        }

        @keyframes spin { to { transform: rotate(360deg); } }

        .input-hint {
          max-width: 860px; margin: 8px auto 0;
          font-size: 11px; color: var(--text-dim);
          text-align: center;
        }

        /* ==================== HD MODAL ==================== */
        .modal-overlay {
          position: fixed; inset: 0; z-index: 200;
          background: rgba(0,0,0,0.7);
          display: flex; align-items: center; justify-content: center;
          padding: 24px;
          backdrop-filter: blur(8px);
          animation: fadeIn 0.2s ease;
        }

        .hd-modal {
          width: 100%; max-width: 580px;
          max-height: 90vh;
          background: rgba(15,0,28,0.95);
          border: 1px solid var(--purple-border);
          border-radius: 24px;
          overflow: hidden; overflow-y: auto;
          box-shadow: 0 0 80px rgba(168,85,247,0.2);
          animation: slideUp 0.3s cubic-bezier(0.16,1,0.3,1);
        }

        .hd-modal::-webkit-scrollbar { width: 4px; }
        .hd-modal::-webkit-scrollbar-thumb { background: var(--purple-border); border-radius: 2px; }

        .modal-header {
          display: flex; align-items: center; justify-content: space-between;
          padding: 24px 28px 20px;
          border-bottom: 1px solid var(--purple-border);
          position: sticky; top: 0;
          background: rgba(15,0,28,0.98);
          backdrop-filter: blur(12px);
          z-index: 1;
        }

        .modal-title {
          font-family: 'Syne', sans-serif;
          font-size: 20px; font-weight: 700;
          display: flex; align-items: center; gap: 10px;
        }

        .hd-badge {
          padding: 3px 10px;
          background: linear-gradient(135deg, #7c3aed, #a855f7);
          border-radius: 6px;
          font-size: 13px; font-weight: 700;
        }

        .modal-close {
          width: 38px; height: 38px;
          background: var(--purple-faint);
          border: 1px solid var(--purple-border);
          border-radius: 10px;
          display: flex; align-items: center; justify-content: center;
          cursor: pointer;
          color: var(--text-secondary);
          transition: all 0.2s;
        }

        .modal-close:hover {
          background: rgba(255,50,50,0.1);
          border-color: rgba(255,50,50,0.3);
          color: #fca5a5;
        }

        .modal-body { padding: 24px 28px 28px; }

        .upload-zone {
          border: 2px dashed var(--purple-border);
          border-radius: 16px;
          min-height: 180px;
          display: flex; align-items: center; justify-content: center;
          cursor: pointer;
          overflow: hidden;
          transition: all 0.2s;
          margin-bottom: 20px;
          position: relative;
        }

        .upload-zone:hover { border-color: var(--purple-bright); background: var(--purple-faint); }

        .upload-placeholder { display: flex; flex-direction: column; align-items: center; gap: 10px; padding: 32px; }

        .upload-icon-wrap { color: var(--purple-bright); opacity: 0.7; }

        .upload-text { font-size: 15px; font-weight: 500; color: var(--text-secondary); }
        .upload-hint-text { font-size: 12px; color: var(--text-dim); }

        .upload-preview {
          max-width: 100%; max-height: 240px;
          object-fit: contain;
          border-radius: 12px;
        }

        .hd-options { display: flex; flex-direction: column; gap: 16px; margin-bottom: 20px; }

        .hd-option-group {}

        .option-label {
          display: block;
          font-size: 13px; font-weight: 500;
          color: var(--text-secondary);
          margin-bottom: 10px;
        }

        .option-toggle {
          display: flex; align-items: center; justify-content: space-between;
          cursor: pointer;
        }

        .quality-btns { display: flex; gap: 8px; }

        .quality-btn {
          flex: 1; padding: 10px;
          background: var(--purple-faint);
          border: 1px solid var(--purple-border);
          border-radius: 10px;
          color: var(--text-secondary);
          font-size: 14px; font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          font-family: 'DM Sans', sans-serif;
        }

        .quality-btn.active {
          background: linear-gradient(135deg, rgba(124,58,237,0.3), rgba(168,85,247,0.2));
          border-color: var(--purple-bright);
          color: var(--purple-light);
        }

        .quality-btn:hover:not(.active) {
          border-color: rgba(168,85,247,0.4);
          color: var(--text-primary);
        }

        .toggle {
          width: 48px; height: 26px;
          background: rgba(255,255,255,0.1);
          border-radius: 100px;
          cursor: pointer;
          position: relative;
          transition: all 0.3s;
          border: 1px solid var(--purple-border);
          flex-shrink: 0;
        }

        .toggle.on {
          background: linear-gradient(135deg, #7c3aed, #a855f7);
          border-color: transparent;
        }

        .toggle-thumb {
          width: 20px; height: 20px;
          border-radius: 50%; background: white;
          position: absolute; top: 2px; left: 2px;
          transition: transform 0.3s;
          box-shadow: 0 2px 6px rgba(0,0,0,0.3);
        }

        .toggle.on .toggle-thumb { transform: translateX(22px); }

        .process-btn {
          width: 100%; padding: 15px;
          background: linear-gradient(135deg, #7c3aed, #a855f7);
          border: none; border-radius: 14px;
          color: white;
          font-size: 15px; font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          display: flex; align-items: center; justify-content: center; gap: 8px;
          box-shadow: 0 6px 24px rgba(168,85,247,0.35);
          font-family: 'DM Sans', sans-serif;
          margin-bottom: 16px;
        }

        .process-btn:hover:not(:disabled) {
          transform: translateY(-1px);
          box-shadow: 0 8px 30px rgba(168,85,247,0.5);
        }

        .process-btn:disabled { opacity: 0.5; cursor: not-allowed; transform: none; }

        .btn-spinner {
          width: 18px; height: 18px;
          border: 2px solid rgba(255,255,255,0.3);
          border-top-color: white;
          border-radius: 50%;
          animation: spin 0.7s linear infinite;
        }

        .hd-error {
          padding: 12px 16px;
          background: rgba(255,50,50,0.1);
          border: 1px solid rgba(255,50,50,0.3);
          border-radius: 10px;
          color: #fca5a5;
          font-size: 14px;
          margin-bottom: 16px;
        }

        .hd-result {
          display: flex; flex-direction: column; gap: 14px;
          animation: fadeIn 0.4s ease;
        }

        .result-badge {
          padding: 10px 16px;
          background: rgba(34,197,94,0.1);
          border: 1px solid rgba(34,197,94,0.3);
          border-radius: 10px;
          color: #86efac;
          font-size: 14px; font-weight: 500;
          text-align: center;
        }

        .result-img {
          width: 100%; border-radius: 12px;
          border: 1px solid var(--purple-border);
        }

        .result-actions { display: flex; }

        .download-btn {
          display: flex; align-items: center; justify-content: center; gap: 8px;
          width: 100%; padding: 13px;
          background: linear-gradient(135deg, rgba(34,197,94,0.2), rgba(34,197,94,0.1));
          border: 1px solid rgba(34,197,94,0.4);
          border-radius: 12px;
          color: #86efac;
          font-size: 14px; font-weight: 600;
          text-decoration: none;
          transition: all 0.2s;
        }

        .download-btn:hover {
          background: linear-gradient(135deg, rgba(34,197,94,0.3), rgba(34,197,94,0.2));
          border-color: #86efac;
          color: #dcfce7;
        }

        @media (max-width: 640px) {
          .header { padding: 0 16px; }
          .header-tagline { display: none; }
          .header-brand { font-size: 17px; }
          .reset-btn span { display: none; }
          .reset-btn { padding: 8px 10px; }
          .messages-list { padding: 0 14px; }
          .input-section { padding: 12px 14px 16px; }
          .bubble { max-width: 85%; font-size: 14px; }
          .welcome-card { padding: 36px 28px; }
          .welcome-title { font-size: 22px; }
          .welcome-brand { font-size: 28px; }
          .modal-header, .modal-body { padding: 18px 20px; }
        }
      `}</style>
    </>
  );
}
